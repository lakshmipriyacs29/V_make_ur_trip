<?php
    include "config.php";
    $selected_bus = $_GET['b_id'];
    $query = "DELETE FROM buses wHERE b_id = $selected_bus";
    $deletebus = mysqli_query($connection, $query);
    
    if(!$deletebus) {
        die("Query Failed" . mysqli_error($connection));
    } 
    header("Location: mylistings.php");   
?>


