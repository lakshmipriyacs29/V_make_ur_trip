<?php
    include "config.php";
    if (isset($_POST['usersignup'])) {
        $u_username = $_POST['u_username'];
        $u_emailid = $_POST['u_emailid'];
        $u_password = $_POST['u_password'];
        $u_phonenumber = $_POST['u_phonenumber'];
        $u_city = $_POST['u_city'];
    $query = "INSERT INTO users(username, emailid, password, phonenumber, city) VALUES('$u_username', '$u_emailid', '$u_password', '$u_phonenumber', '$u_city') ";
    
    $register_user = mysqli_query($connection, $query);
    
    if(!$register_user) {
        die("Query Failed" . mysqli_error($connection));
    }
    
    header("Location: userlogin.html");
    }
    
    ?>