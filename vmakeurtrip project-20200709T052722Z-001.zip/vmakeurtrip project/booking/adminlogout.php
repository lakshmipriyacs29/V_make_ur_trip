<?php session_start(); ?>
<?php 
 $_SESSION['a_id']=null;
 $_SESSION['a_agencyname']=null;
 $_SESSION['a_type']=null;
 $_SESSION['a_address']=null;
 $_SESSION['a_email']=null;
 $_SESSION['a_pwd']=null;
 $_SESSION['a_phno']=null;
 $_SESSION['a_ownername']=null;

header("Location: adminlogin.html");

?>