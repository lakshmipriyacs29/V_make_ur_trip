<?php
    include "config.php";
    session_start();
    if (isset($_POST['uploadhotel'])) {
        $h_name = $_POST['h_name'];
        $h_address = $_POST['h_address'];
        $h_city = $_POST['h_city'];
        $h_mobileno = $_POST['h_mobileno'];
        $h_description = $_POST['h_description'];
        $h_ownername = $_POST['h_ownername'];
        $h_email = $_POST['h_email'];
        $h_roomsavailable = $_POST['h_roomsavailable'];
        $h_image = $_FILES['h_image']['name'];
        $tmp_image = $_FILES['h_image']['tmp_name'];
        move_uploaded_file($tmp_image, "hotelimages/$h_image");
        $h_fair = $_POST['h_fair'];
        $a_id = $_SESSION['a_id'];
    $query = "INSERT INTO hotels(h_name,h_address,h_mobileno,h_description,h_city,h_ownername,h_email,h_roomsavailable,h_image,h_fair,a_id) VALUES('$h_name','$h_address','$h_mobileno','$h_description','$h_city','$h_ownername','$h_email','$h_roomsavailable','$h_image','$h_fair','$a_id') ";
    
    $addhotel = mysqli_query($connection, $query);
    
    if(!$addhotel) {
        die("Query Failed" . mysqli_error($connection));
    }
    
    header("Location: uploadhotel.php");
    }
    
    ?>