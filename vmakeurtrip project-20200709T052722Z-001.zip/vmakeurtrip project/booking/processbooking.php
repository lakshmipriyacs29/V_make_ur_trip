<?php
include 'config.php';
session_start();
if (isset($_POST['checkout'])) 
{
    $adminid = $_GET['a_id'];
    $bus_id = $_GET['b_id'];
    $user_id = $_SESSION['u_id'];
    $da=$_SESSION['date'];
    $username=$_SESSION['username'];
    $from=$_GET['from'];
    $to=$_GET['to'];
    $b_travalname=$_GET['bustravelname'];
    
    $busfair = $_GET['busfair'];
    $nooftickets = $_GET['nooftickets'];
    $cost = $nooftickets * $busfair;
    $ticketno = rand();
    $qu = "INSERT INTO orderss(admin_id,bus_id,user_id,user_name,edate,efrom,eto,no_of_ticket,ticketno,cost,b_travelname) VALUES($adminid,$bus_id,$user_id,'$username','$da','$from','$to',$nooftickets,$ticketno,$cost,'$b_travalname')";
    $booking_query=mysqli_query($connection,$qu);
    if (!$booking_query) {
            die("Query Failed" . mysqli_error($connection));
        }

    header("Location: thankyou.html");
}
?>



<!-- <?php
include 'config.php';
session_start();
if (isset($_POST['chckout'])) {
    $nooftickets = $_GET['nooftickets'];
    $adminid = $_GET['a_id'];
    $bus_id = $_GET['b_id'];

    $source = $_POST['src'];
    $u_destination = $_POST['dest'];
    $busfair = $_GET['busfair'];
    $cost = $nooftickets * $busfair;
    $ticketno = rand();
    $arr = array();
    $arr1 = array();
    for ($i=0; $i < $nooftickets; $i++) {
        //echo "<h1>hello</h1>";
        $name_query = 'name'.$i ;
        $age_query = 'age'.$i ;
        //echo $what;
        array_push($arr,$_POST[$name_query]);
        array_push($arr1,$_POST[$age_query]);
    }

        $curr_name = $arr[$i];
        $curr_age = $arr1[$i];
        $user_id = $_SESSION['u_id'];
        $arr = serialize($arr);
        $arr1 = serialize($arr1);
        $query = "INSERT INTO orders(bus_id,user_id,user_name,user_age,source,destination,cost,admin_id,ticketno) VALUES('$bus_id', '$user_id', '$arr', '$arr1', '$source','$u_destination','$cost','$adminid','$ticketno')";

        // $query_seat_update = "UPDATE buses SET noofseats = $noofseats + $nooftickets WHERE post_id = $bus_id";

        //echo $arr[$i];
        //echo $_SESSION['s_id'];
        // $update_seats_available = mysqli_query($connection,$query_seat_update);
        $booking_query = mysqli_query($connection,$query);
        if (!$booking_query) {
            die("Query Failed" . mysqli_error($connection));
        }

    header("Location: thankyou.html");
}

?>   -->