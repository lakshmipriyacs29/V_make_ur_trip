<?php
    include "config.php";
    if (isset($_POST['adminsignup'])) {
        $a_agencyname = $_POST['a_agencyname'];
        $a_type = $_POST['a_type'];
        $a_address = $_POST['a_address'];
        $a_email = $_POST['a_email'];
        $a_pwd = $_POST['a_pwd'];
        $a_phno = $_POST['a_phno'];
        $a_ownername = $_POST['a_ownername'];
    $query = "INSERT INTO adminusers(a_agencyname, a_type, a_address, a_email, a_pwd, a_phno, a_ownername) VALUES('$a_agencyname', '$a_type', '$a_address', '$a_email', '$a_pwd', '$a_phno', '$a_ownername') ";
    
    $register_user = mysqli_query($connection, $query);
    
    if(!$register_user) {
        die("Query Failed" . mysqli_error($connection));
    }
    
    header("Location: adminlogin.html");
    }
    
    ?>