<!DOCTYPE html>
<html lang="en">
  <head>
    <title>VMAKEURTRIP</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
 
    <link rel="short icon" type="image/png" href="urtrip.png" sizes="16X16"><!--Favicon-->
    <link
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container-fluid px-md-4	">
        <a class="navbar-brand" href="index.php">VMAKEURTRIP</a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item cta mr-md-1">
              <a href="userlogin.html" class="nav-link">Login</a>
            </li>
            <li class="nav-item cta cta-colored">
              <a href="usersignup.html" class="nav-link">Signup</a>
            </li> 
            <li class="nav-item cta mr-md-1">
              <a href="adminlogin.html" class="nav-link">Admin</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    <?php 
                    include "config.php";
                    $query_hotel_orders = "SELECT *  FROM  order_hotel";
                    $select_all_hotelorders = mysqli_query($connection,$query_hotel_orders);
                    $count_hotelorders = mysqli_num_rows($select_all_hotelorders);
                    $query_bus_orders = "SELECT *  FROM  orderss";
                    $select_all_busorders = mysqli_query($connection,$query_bus_orders);
                    $count_busorders = mysqli_num_rows($select_all_busorders);
                    $query_bus = "SELECT *  FROM  buses";
                    $select_all_bus = mysqli_query($connection,$query_bus);
                    $count_buses = mysqli_num_rows($select_all_bus);
                    $query_hotels = "SELECT *  FROM  hotels";
                    $select_all_hotels = mysqli_query($connection,$query_hotels);
                    $count_hotels = mysqli_num_rows($select_all_hotels);
                    $qu="SELECT city FROM LOCATIONS";
                    $q=mysqli_query($connection,$qu);
                    $q1=mysqli_query($connection,$qu);
                    $q2=mysqli_query($connection,$qu);
                    
                ?>
    <div class="hero-wrap img" style="background-image: url(images/bg_1.jpg);">
      <div class="overlay"></div>
      <div class="container">
        <div
          class="row d-md-flex no-gutters slider-text align-items-center justify-content-center"
        >
          <div class="col-md-10 d-flex align-items-center ftco-animate">
            <div class="text text-center pt-5 mt-md-5">
              <p class="mb-4">Find Hotels and Buses in single click</p>
              <h1 class="mb-5">The Easiest way to make your Trip...</h1>
              <div class="ftco-counter ftco-no-pt ftco-no-pb">
                <div class="row">
                  <div
                    class="col-md-4 d-flex justify-content-center counter-wrap ftco-animate"
                  >
                    <div class="block-18">
                      <div class="text d-flex">
                        <div class="icon mr-2">
                          <span class="flaticon-worldwide"></span>
                        </div>
                        <div class="desc text-left">
                          <strong class="number" data-number="<?php echo $count_hotels; ?>">0</strong>
                          <span>No. of Hotel Partners</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    class="col-md-4 d-flex justify-content-center counter-wrap ftco-animate"
                  >
                    <div class="block-18 text-center">
                      <div class="text d-flex">
                        <div class="icon mr-2">
                          <span class="flaticon-visitor"></span>
                        </div>
                        <div class="desc text-left">
                          <strong class="number" data-number="<?php echo $count_buses; ?>">0</strong>
                          <span>No.of Bus agencies</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    class="col-md-4 d-flex justify-content-center counter-wrap ftco-animate"
                  >
                    <div class="block-18 text-center">
                      <div class="text d-flex">
                        <div class="icon mr-2">
                          <span class="flaticon-resume"></span>
                        </div>
                        <div class="desc text-left">
                          <strong class="number" data-number="<?php echo $count_hotelorders+$count_busorders; ?>">0</strong>
                          <span>Bookings till now</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="ftco-search my-md-5">
                <div class="row">
                  <div class="col-md-12 nav-link-wrap">
                    <div
                      class="nav nav-pills text-center"
                      id="v-pills-tab"
                      role="tablist"
                      aria-orientation="vertical"
                    >
                      <a
                        class="nav-link active mr-md-1"
                        id="v-pills-1-tab"
                        data-toggle="pill"
                        href="#v-pills-1"
                        role="tab"
                        aria-controls="v-pills-1"
                        aria-selected="true"
                        >Book Buses</a
                      >

                      <a
                        class="nav-link"
                        id="v-pills-2-tab"
                        data-toggle="pill"
                        href="#v-pills-2"
                        role="tab"
                        aria-controls="v-pills-2"
                        aria-selected="false"
                        >Book Hotels</a
                      >
                    </div>
                  </div>
                  <div class="col-md-12 tab-wrap">
                    <div class="tab-content p-4" id="v-pills-tabContent">
                      <div
                        class="tab-pane fade show active"
                        id="v-pills-1"
                        role="tabpanel"
                        aria-labelledby="v-pills-nextgen-tab"
                      >
                        <form action="userlogin.html" class="search-job">
                          <div class="row no-gutters">
                            <div class="col-md mr-md-4">
                              <div class="form-group">
                                <div class="form-field">
                                  <div class="select-wrap">
                                    <select class="form-control" name="src">
                                      <option>From</option>
                                      <?php
                                      while($r=mysqli_fetch_array($q)){
                                      ?>
                                      <option value="<?php echo $r['city']; ?>"><?php echo $r['city']; ?></option>     <?php
                                        }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md mr-md-4">
                              <div class="form-group">
                                <div class="form-field">
                                  <div class="select-wrap">
                                    <select class="form-control" name="dest">
                                      <option>To</option>
                                      <?php
                                      while($r=mysqli_fetch_array($q1)){
                                      ?>
                                      <option value="<?php echo $r['city']; ?>"><?php echo $r['city']; ?></option>     <?php
                                        }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md mr-md-4">
                              <div class="form-group">
                                <div class="form-field">
                                  <div class="icon">
                                    <span class="icon-map-marker"></span>
                                  </div>
                                  <input
                                    type="date"
                                    class="form-control"
                                    placeholder="Date"
                                    name="dateof"
                                  />
                                </div>
                              </div>
                            </div>
                            <div class="col-md">
                              <div class="form-group">
                                <div class="form-field">
                                  <button
                                    type="submit"
                                    name="searchbus"
                                    class="form-control btn btn-primary">
                                  
                                    Search
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>

                      <div
                        class="tab-pane fade"
                        id="v-pills-2"
                        role="tabpanel"
                        aria-labelledby="v-pills-performance-tab"
                      >
                        <form action="userlogin.html" class="search-job">
                          <div class="row">
                            <div class="col-md">
                              <div class="form-group">
                                <div class="form-field">
                                  <select class="form-control" name="search_location">
                                      <option>Select Location</option>
                                      <?php
                                      while($r=mysqli_fetch_array($q2)){
                                      ?>
                                      <option value="<?php echo $r['city']; ?>"><?php echo $r['city']; ?></option>     <?php
                                        }
                                      ?>
                                    </select>
                                </div>
                              </div>
                            </div>
                            <div class="col-md">
                              <div class="form-group">
                                <div class="form-field">
                                  <button
                                    type="submit"
                                    name="search_hotel"
                                    class="form-control btn btn-primary"
                                  >
                                    Search
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
      <svg class="circular" width="48px" height="48px">
        <circle
          class="path-bg"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke="#eeeeee"
        />
        <circle
          class="path"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke-miterlimit="10"
          stroke="#F96D00"
        />
      </svg>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
