<?php

$connection = mysqli_connect("localhost",'root','','booking');

if(!$connection) {
	die("Unable to connect" . mysqli_error($connection));
}

?>