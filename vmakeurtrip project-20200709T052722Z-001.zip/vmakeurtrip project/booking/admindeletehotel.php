<?php
    include "config.php";
    $selected_bus = $_GET['h_id'];
    $query = "DELETE FROM hotels wHERE h_id = $selected_bus";
    $deletehotel = mysqli_query($connection, $query);
    
    if(!$deletehotel) {
        die("Query Failed" . mysqli_error($connection));
    } 
    header("Location: mylistinghotel.php");   
?>