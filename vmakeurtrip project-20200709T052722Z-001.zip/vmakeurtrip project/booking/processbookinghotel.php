<?php
include 'config.php';
session_start();
if (isset($_POST['checkouthotel'])) {
    $nooftickets = $_GET['nooftickets'];
    $adminid = $_GET['a_id'];
    $h_id = $_SESSION['h_id'];
    $checkin = $_GET['checkin'];
    $user_name=$_SESSION['username'];
    $add=$_POST['add'];
    $phone=$_POST['phone'];
    $checkout = $_GET['checkout'];
    $user_id = $_SESSION['u_id'];
    $cost =$_GET['h_fair'];
    $h_name=$_GET['h_name'];
    $h_address=$_GET['h_address'];
    $ticketno = rand();
    $query = "INSERT INTO order_hotel(h_id,user_id,user_name,address,phone,checkin,checkout,cost,admin_id,ticketno,h_name,h_address) VALUES($h_id, $user_id , '$user_name', '$add','$phone', '$checkin', '$checkout',$cost,$adminid,$ticketno,'$h_name','$h_address');";

    $booking_query = mysqli_query($connection,$query) ;
        if (!$booking_query) {
            die("Query Failed" . mysqli_error($connection));
        }
    header("Location: thankyou.html");
}
?>




<?php
/*include 'config.php';
session_start();
if (isset($_POST['chekouthotel'])) {
    $nooftickets = $_GET['nooftickets'];
    $adminid = $_GET['a_id'];
    $h_id = $_GET['h_id'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $h_fair = $_GET['h_fair'];
    $cost = $h_fair;
    $ticketno = rand();
    $arr = array();
    $arr1 = array();
    for ($i=0; $i < $nooftickets; $i++) {
        //echo "<h1>hello</h1>";
        $name_query = 'name'.$i ;
        $age_query = 'age'.$i ;
        //echo $what;
        array_push($arr,$_POST[$name_query]);
        array_push($arr1,$_POST[$age_query]);
    }

        $curr_name = $arr[$i];
        $curr_age = $arr1[$i];
        $arr = serialize($arr);
        $arr1 = serialize($arr1);
        $user_id = $_SESSION['u_id'];
        $query = "INSERT INTO order_hotel(h_id, user_id, user_name, user_age, checkin, checkout,cost,admin_id,ticketno) VALUES($h_id, $user_id , '$arr', '$arr1', '$checkin', '$checkout',$cost,$adminid,$ticketno)";

        // $query_seat_update = "UPDATE buses SET noofseats = $noofseats + $nooftickets WHERE post_id = $bus_id";

        //echo $arr[$i];
        //echo $_SESSION['s_id'];
        // $update_seats_available = mysqli_query($connection,$query_seat_update);
        $booking_query = mysqli_query($connection,$query);
        if (!$booking_query) {
            die("Query Failed" . mysqli_error($connection));
        }
    header("Location: thankyou.html");
}

?>*/