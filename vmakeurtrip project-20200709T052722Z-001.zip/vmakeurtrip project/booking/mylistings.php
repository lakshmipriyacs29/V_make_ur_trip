<!DOCTYPE html>
<?php

session_start();

?>
<html lang="en">
  <head>
    <title>Admin-Mylisting</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
<link rel="short icon" type="image/png" href="urtrip.png" sizes="16X16"><!--Favicon-->
    <link
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
  <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container-fluid px-md-4	">
        <a class="navbar-brand" href="index.php">VMAKEURTRIP-Admin</a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>
         <?php

         ?>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a href="admin.php" active class="nav-link">Dashboard</a>
            </li>
            <?php if($_SESSION['a_type'] == "bus"){ ?>
            <li class="nav-item">
              <a href="uploadbus.php" class="nav-link">Upload Buses</a>
            </li>
            <?php }
            else{ 
              $session_a_id = $_SESSION['a_id'];
              $query = "SELECT * FROM hotels WHERE a_id = $session_a_id";
              $select_a_id = mysqli_query($connection,$query);
              
	            while ($row = mysqli_fetch_assoc($select_a_id)) {
                $db_a_id=$row['a_id'];
                if($session_a_id === $db_a_id) {
                }  
                else{
            ?>
            <li class="nav-item">
              <a href="uploadhotel.php" class="nav-link">Upload Hotel</a>
            </li>
            <?php }}} ?>
            <?php if($_SESSION['a_type'] == "bus"){ ?>
            <li class="nav-item">
              <a href="mylistings.php"  class="nav-link">My Listings</a>
            </li>
            <?php }  else { ?>
              <li class="nav-item">
              <a href="mylistinghotel.php"  class="nav-link">My Listings</a>
            </li>
            <?php } ?>
            <?php if($_SESSION['a_type'] == "bus"){ ?>
            <li class="nav-item">
              <a href="mybusbooking.php" active class="nav-link">Bookings</a>
            </li>
            <?php }  else { ?>
            <li class="nav-item">
              <a href="myhotelbooking.php" active class="nav-link">Bookings</a>
            </li>
            <?php }?>
            <li class="nav-item cta mr-md-1">
              <a href="adminlogout.php" class="nav-link">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <div
      class="hero-wrap hero-wrap-2"
      style="background-image: url('images/bg_1.jpg');"
      data-stellar-background-ratio="0.5"
    >
      <div class="overlay"></div>
      <div class="container">
        <div
          class="row no-gutters slider-text align-items-end justify-content-start"
        >
          <div class="col-md-12 ftco-animate text-center mb-5">
            <p class="breadcrumbs mb-0">
              <span class="mr-3"
                ><a href="admin.php"
                  >Home <i class="ion-ios-arrow-forward"></i></a
              ></span>
              <span>My Listings</span>
            </p>
            <h1 class="mb-3 bread">My Listings</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section ftco-candidates ftco-candidates-2 bg-light">
      <div class="container">
      <?php 
                    include "config.php";
                    $admin_id = $_SESSION['a_id'];
                    $query = "SELECT *  FROM  buses WHERE a_id = $admin_id";
                    $select_all_buses = mysqli_query($connection,$query);

                    $count = mysqli_num_rows($select_all_buses);
                    if($count == 0) {
                        echo "<h1>No Buses Added</h1>";
                    }
                    else {
                    while($row = mysqli_fetch_assoc($select_all_buses)) {
                        $b_id = $row['b_id'];
                        $b_busno = $row['b_busno'];
                        $b_from = $row['b_from'];
                        $b_to = $row['b_to'];
                        $b_travelname = $row['b_travelname'];
                        $b_duration = $row['b_duration'];
                        $b_type = $row['b_type'];
                        $b_boardingstation = $row['b_boardingstation'];
                        $start = $row['b_boardingstationtiming'];
                        $end=$row['b_bordingstationarrival'];
                        $b_fair = $row['b_fair'];
                        $b_noofseats = $row['b_noofseats'];
                        $b_image = $row['b_image'];
                        $b_phno = $row['b_phno'];
                        $a_id = $row['a_id'];
                ?>
        <div class="row">
          <div class="col-lg-12 pr-lg-4">
            <div class="row">
              <div class="col-md-12">
                <div class="team d-md-flex p-4 bg-white">
                  <div
                    class="img"
                    style="background-image: url(busimages/<?php echo $b_image; ?>);"
                  ></div>
                  <div class="text pl-md-4">
					<span class="location mb-0" class="subadge"></span>
					<div class="row">
						<div class="col-md-4">
					     <b><?php echo $b_travelname ?></b> &NonBreakingSpace; 
						</div>
						<div class="col-md-4">
					     <b><?php echo $b_from ?> - <?php echo $b_to ?></b></span>
            </div>
					  <div class="col-md-4">
					    <span ><b>Start: <?php echo $start;?></span> - <span>Arrival: <?php echo $end; ?></b></span>
				    </div>
			   </div>

			  <div class="row">
				  <div class="col-md-4">
              <p class="mb-2">
                  <b> <?php echo $b_noofseats ?> Seats</b>
					    </p>
				  </div>
					<div class="col-md-4">
						  <p class="mb-2"><b>Duration: <?php echo $b_duration ?></b></p>
          </div>  
        </div>	
        <div class="row">
				   <div class="col-md-4"> 
             <p><a href="admindeletebus.php?b_id=<?php echo $b_id; ?>" name="deletebus" class="btn btn-primary">Delete Bus</a></p>
           </div>
         </div>    
       </div>
     </div>
   </div>
 </div>
</div>
    
</div>
   <?php }} ?>
</div>
 </section>

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
      <svg class="circular" width="48px" height="48px">
        <circle
          class="path-bg"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke="#eeeeee"
        />
        <circle
          class="path"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke-miterlimit="10"
          stroke="#F96D00"
        />
      </svg>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
