<!DOCTYPE html>
<?php 
include 'config.php';
session_start();
  if (!isset($_SESSION["u_id"]))
   {
      header("location: userlogin.html");
   }
   if (isset($_POST['bookhotel'])) {
    $nooftickets = $_POST['nooftickets'];
    
    
    $h_id = $_GET['h_id'];
    $_SESSION['h_id']=$h_id;
  }
  // if(isset($_GET['s']))
  // {
  //   $h_id = $_GET['h_id'];
  // }
  ?>

<html lang="en">
  <head>
    <title>Available Hotels</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
<link rel="short icon" type="image/png" href="urtrip.png" sizes="16X16"><!--Favicon-->
    <link
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container-fluid px-md-4	">
        <a class="navbar-brand" href="index.php">VMAKEURTRIP</a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><p class="nav-link">Hi <?php echo $_SESSION['username']; ?> !</p></li>
            <li class="nav-item cta cta-colored">
                <a href="mytickets.php" class="nav-link">My Tickets</a>
              </li>
              <li><pre> </pre></li>
              <li class="nav-item cta cta-colored">
                <a href="userlogout.php" class="nav-link">Logout</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <div
      class="hero-wrap hero-wrap-2"
      style="background-image: url('images/bg_1.jpg');"
      data-stellar-background-ratio="0.5"
    >
      <div class="overlay"></div>
      <div class="container">
        <div
          class="row no-gutters slider-text align-items-end justify-content-start"
        >
          <div class="col-md-12 ftco-animate text-center mb-5">
            <p class="breadcrumbs mb-0">
              <span class="mr-3"
                ><a href="index.html"
                  >Home <i class="ion-ios-arrow-forward"></i></a
              ></span>
              <span>Book Hotl</span>
            </p>
            <h1 class="mb-3 bread">Book hotel</h1>
          </div>
        </div>
      </div>
    </div>
    <?php 
                    include "config.php";
                    // $admin_id = $_SESSION['a_id'];
                    $query = "SELECT *  FROM  hotels WHERE h_id =". $_SESSION['h_id']."";
                    $select_all_hotels = mysqli_query($connection,$query);

                    $count = mysqli_num_rows($select_all_hotels);
                    if($count == 0) {
                        echo "<h1>No Hotels Added</h1>";
                    }
                    else {
                    while($row = mysqli_fetch_assoc($select_all_hotels)) {
                        $h_id = $row['h_id'];
                        $h_name = $row['h_name'];
                        $h_address = $row['h_address'];
                        $h_mobileno = $row['h_mobileno'];
                        $h_description = $row['h_description'];
                        $h_ownername = $row['h_ownername'];
                        $h_email = $row['h_email'];
                        $h_roomsavailable = $row['h_roomsavailable'];
                        $h_image = $row['h_image'];
                        $h_fair = $row['h_fair'];
                        $a_id = $row['a_id'];
                ?>
<section class="ftco-section ftco-candidates ftco-candidates-2 bg-light">
      <div class="container">
      <div class="row">
          <div class="col-lg-12 pr-lg-4">
            <div class="row">
              <div class="col-md-12">
                <div class="team d-md-flex p-4 bg-white">
                  <div
                    class="img"
                    style="background-image: url(hotelimages/<?php echo $h_image; ?>);"
                  ></div>
                  <div class="text pl-md-4">
          <span class="location mb-0" class="subadge"></span>
          <div class="row">
            <div class="col-md-3">
            <b><?php echo $h_name ?></b> &NonBreakingSpace; 
            </div>
            <div class="col-md-5">
            <b>Address: <?php echo $h_address ?></b></span>
                    </div>
                    <!-- Your Task-->
          <div class="col-md-4">
          <span><b>Mobile No: <?php echo $h_mobileno; ?> </span></b>
        </div>
      </div>

      <div class="row">
        <div class="col-md-3">
                    <p class="mb-2">
                     <b> <?php echo $h_roomsavailable ?> Rooms Available</b>
          </p>
        </div>
          <div class="col-md-5">
            <p class="mb-2">
                       <b>Email: <?php echo $h_email ?></b>
              </p>
                    </div>
                    <div class="col-md-4">
            <p class="mb-2">
                        <b> Rs.<?php echo $h_fair ?>/Per Day </b>
              </p>
          </div>
            </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
    
        </div>
      </div>
</section>
    <?php }} ?>
     <?php
              if(isset($_GET['s']))
              {
                $in=date_create($_GET['checkin']);
                $out=date_create($_GET['checkout']);
                $bill=date_diff($in,$out);
                $f=$bill->format("%a") * $h_fair;
                
              ?>
               <?php
           }

             ?> 
    <section class="ftco-section contact-section bg-light">
      <div class="container">
        <div class="row block-9">
            <div class="col-md-12 order-md-last d-flex">
              
              <form action="processbookinghotel.php?a_id=<?php echo $a_id; ?>&nooftickets=<?php echo $nooftickets; ?>&h_id=<?php echo $h_id; ?>&h_fair=<?php echo $f; ?>" method="POST" class="bg-white p-5 contact-form">
              
              <label>Name: </label><input type="text" name="name" value="<?php echo $_SESSION['username']; ?>" class="form-control">
              <label>Address</label>
                <textarea class="form-control" required name="add"></textarea>
              <label>Phono No:</label>
                <input type="text" name="phone" required class="form-control">
                <label>Check In</label>
                <input type="date" disabled class="form-control" value="<?php echo $_GET['checkin'];?>" placeholder="checkin" name="checkin"  required>
              <label>Check Out</label>
                <input type="date" disabled class="form-control" placeholder="checkout" value="<?php echo $_GET['checkout']; ?>"name="checkout" required>
               <br>
              <h4><b>You need to Pay: <?php echo $f; ?></b></h4>
<br>
              <input type="submit" value="Pay Bill" name="checkouthotel"  class="btn btn-primary py-3 px-5">
             </form>
           
            </div>              
              
             
            <!-- <form
              action="processbookinghotel.php?a_id=<?php echo $a_id; ?>&nooftickets=<?php echo $nooftickets; ?>&h_id=<?php echo $h_id; ?>&h_fair=<?php echo $h_fair; ?>"
              method="POST"
              class="bg-white p-5 contact-form"
            >
              <div class="form-group">
              <label>Check In</label>
                <input type="date" class="form-control" placeholder="checkin" name="checkin" required>
            

              </div>
              <div class="form-group">
              <label>Check Out</label>
                <input
                  type="date"
                  class="form-control"
                  placeholder="checkout"
                  name="checkout"
                  required
                >
            
              </div>
              <?php

                if (isset($_POST['nooftickets'])) {
                    $count = $_POST['nooftickets'];
                    //echo "<h1>$count</h1>";

                    for ($i=0; $i < $count; $i++) { 

                        ?>
                        <h6><?php echo "Member "; echo $i+1;?></h6>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Name:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" id="email" placeholder="Name" name="name<?php echo "$i" ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Age:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" id="email" placeholder="Age" name="age<?php echo "$i" ?>">
                            </div>
                        </div>
                        <?php
                    }

                }

                ?>
                <hr>
             <h3>You need to pay: <?php echo $nooftickets * $h_fair; ?></h3>
                <hr>
              <div class="form-group">
                <input
                  type="submit"
                  value="Book Bus"
                  name="checkouthotel"
                  class="btn btn-primary py-3 px-5"
                />
              </div>
            </form>
  -->           
          </div>

          <div class="col-md-6 d-flex">
            <div id="map" class="bg-white"></div>
          </div>
        </div>
      </div>
    </section>

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
      <svg class="circular" width="48px" height="48px">
        <circle
          class="path-bg"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke="#eeeeee"
        />
        <circle
          class="path"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke-miterlimit="10"
          stroke="#F96D00"
        />
      </svg>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
  </html>