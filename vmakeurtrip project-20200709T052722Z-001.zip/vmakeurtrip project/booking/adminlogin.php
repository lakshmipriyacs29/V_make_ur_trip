<?php include "config.php"; ob_start(); ?>
<?php session_start(); ?>
<?php 

if (isset($_POST['adminlogin'])) {
	$emailid = $_POST['a_email'];
	$password = $_POST['a_pwd'];

	$query = "SELECT * FROM adminusers WHERE a_email = '$emailid'";
	$select_user = mysqli_query($connection,$query);

	if (!$select_user) {
		die("Query Failed" . mysqli_error($connection));
    }

	while ($row = mysqli_fetch_assoc($select_user)) {
        $db_a_id=$row['a_id'];
		$db_a_agencyname = $row['a_agencyname'];
        $db_a_type = $row['a_type'];
        $db_a_address = $row['a_address'];
        $db_a_email = $row['a_email'];
        $db_a_pwd = $row['a_pwd'];
        $db_a_phno = $row['a_phno'];
        $db_a_ownername = $row['a_ownername'];

		if($emailid === $db_a_email && $password === $db_a_pwd) {
            $_SESSION['a_id']=$db_a_id;
		    $_SESSION['a_agencyname']=$db_a_agencyname;
		    $_SESSION['a_type']=$db_a_type;
		    $_SESSION['a_address']=$db_a_address;
		    $_SESSION['a_email']=$db_a_email;
		    $_SESSION['a_pwd']=$db_a_pwd;
            $_SESSION['a_phno']=$db_a_phno;
            $_SESSION['a_ownername']=$db_a_ownername;
			header("Location: admin.php");
			exit;			
		}
		else {
			echo("Password is wrong");
			exit;
		}
	}
}

?>