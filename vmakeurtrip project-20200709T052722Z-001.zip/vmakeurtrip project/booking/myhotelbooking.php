<!DOCTYPE html>
<?php
include "config.php";
session_start();

?>
<html lang="en">
  <head>
    <title>Admin-HotelBooking</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
<link rel="short icon" type="image/png" href="urtrip.png" sizes="16X16"><!--Favicon-->
    <link
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
  <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container-fluid px-md-4	">
        <a class="navbar-brand" href="index.html">VMAKEURTRIP-Admin</a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>
         <?php

         ?>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a href="admin.php" active class="nav-link">Dashboard</a>
            </li>
            <?php 
            if($_SESSION['a_type'] == "bus")
              {
                ?>
                <li class="nav-item">
                <a href="uploadbus.php" class="nav-link">Upload Buses</a>
                </li>
            <?php 
              }  
            else 
              { 
                ?>
                <li class="nav-item">
                <a href="uploadhotel.php" class="nav-link">Upload Hotel</a>
                </li>
            <?php 
              }
              ?>
            <?php if($_SESSION['a_type'] == "bus"){ ?>
            <li class="nav-item">
              <a href="mylistings.php"  class="nav-link">My Listings</a>
            </li>
            <?php }  else { ?>
              <li class="nav-item">
              <a href="mylistinghotel.php"  class="nav-link">My Listings</a>
            </li>
            <?php } ?>
            <?php if($_SESSION['a_type'] == "bus"){ ?>
            <li class="nav-item">
              <a href="mybusbooking.php" active class="nav-link">Bookings</a>
            </li>
            <?php }  else { ?>
            <li class="nav-item">
              <a href="myhotelbooking.php" active class="nav-link">Bookings</a>
            </li>
            <?php }?>
            <li class="nav-item cta mr-md-1">
              <a href="adminlogout.php" class="nav-link">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <div
      class="hero-wrap hero-wrap-2"
      style="background-image: url('images/bg_1.jpg');"
      data-stellar-background-ratio="0.5"
    >
      <div class="overlay"></div>
      <div class="container">
        <div
          class="row no-gutters slider-text align-items-end justify-content-start"
        >
          <div class="col-md-12 ftco-animate text-center mb-5">
            <p class="breadcrumbs mb-0">
              <span class="mr-3"
                ><a href="admin.php"
                  >Home <i class="ion-ios-arrow-forward"></i></a
              ></span>
              <span>Bookings</span>
            </p>
            <h1 class="mb-3 bread">My Bookings</h1>
          </div>
        </div>
      </div>
    </div>
     <?php 
                    include "config.php";
                    $admin_id = $_SESSION['a_id'];
                    $query = "SELECT *  FROM  order_hotel WHERE admin_id = $admin_id";
                    $select_all_tickets = mysqli_query($connection,$query);
                    $count = mysqli_num_rows($select_all_tickets);
                    if($count == 0) {
                        echo "<h1>No Hotel Tickets</h1>";
                    }
                    else {
                    while($row = mysqli_fetch_assoc($select_all_tickets)) {
                        $o_id = $row['o_id'];
                        $h_id = $row['h_id'];
                        $user_name = $row['user_name'];
                        $user_age = $row['address'];
                        $h_name=$row['h_name'];
                        $h_address=$row['h_address'];
                        $checkin = $row['checkin'];
                        $checkout = $row['checkout'];
                        $admin_id = $row['admin_id'];
                        $cost = $row['cost'];
                        $ticketno = $row['ticketno'];
                        $len_tickets = count($user_name);
                ?>
    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 pr-lg-4">
            <div class="row">
              <div class="col-md-12 ftco-animate">
                <div
                  class="job-post-item p-4 d-block d-lg-flex align-items-center"
                >
                  <div class="one-third mb-4 mb-md-0">
                    <div class="job-post-item-header align-items-center">
                      <h4 class="mr-3 text-black">
                        <?php echo $user_name; ?>
                      </h4> 
                      <h5 class="mr-3 text-black">
                        <?php echo $h_name; ?>
                      </h5> 
                      <span class="subadge"><?php echo $h_address; ?></span>
                      
                      <h6><?php echo $checkin; ?> to <?php echo $checkout; ?></h6>
                    </div> 
                    <div class="job-post-item-body d-block d-md-flex">
                      <div class="mr-3">
                        <span class="icon-layers"></span>
                        <a href="#">Booking No: <?php echo $ticketno; ?></a>
                      </div>
                      <div>
                        <span class="icon-my_location"></span>
                        <span>Cost: <?php echo $cost; ?></span>
                      </div>
                    </div>
                  </div>

                  <div
                    class="one-forth ml-auto d-flex align-items-center mt-4 md-md-0"
                  >
                   
                    
                  </div>
                </div>
              </div>
              <!-- end -->
            </div>
          </div>
        </div>
      </div>
    </section>
                    <?php }} ?>
    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
      <svg class="circular" width="48px" height="48px">
        <circle
          class="path-bg"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke="#eeeeee"
        />
        <circle
          class="path"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke-miterlimit="10"
          stroke="#F96D00"
        />
      </svg>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
