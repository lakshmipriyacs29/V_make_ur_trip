<!DOCTYPE html>
<?php 
include 'config.php';
session_start();
  if (!isset($_SESSION["s_id"]))
   {
      header("location: userlogin.html");
   }
   if (isset($_POST['checkout'])) {
    $nooftickets = $_GET['nooftickets'];
    $b_id = $_GET['b_id'];

  }
  ?>

<html lang="en">
  <head>
    <title>Checkout Tickets</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
<link rel="short icon" type="image/png" href="urtrip.png" sizes="16X16"><!--Favicon-->
    <link
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container-fluid px-md-4	">
        <a class="navbar-brand" href="index.php">VMAKEURTRIP</a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><p class="nav-link">Hi <?php echo $_SESSION['username']; ?> !</p></li>
            <li class="nav-item cta cta-colored">
                <a href="mytickets.php" class="nav-link">My Tickets</a>
              </li>
              <li><pre> </pre></li>
              <li class="nav-item cta cta-colored">
                <a href="userlogout.php" class="nav-link">Logout</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <div
      class="hero-wrap hero-wrap-2"
      style="background-image: url('images/bg_1.jpg');"
      data-stellar-background-ratio="0.5"
    >
      <div class="overlay"></div>
      <div class="container">
        <div
          class="row no-gutters slider-text align-items-end justify-content-start"
        >
          <div class="col-md-12 ftco-animate text-center mb-5">
            <p class="breadcrumbs mb-0">
              <span class="mr-3"
                ><a href="index.php"
                  >Home <i class="ion-ios-arrow-forward"></i></a
              ></span>
              <span>Book Hotel</span>
            </p>
            <h1 class="mb-3 bread">Book Hotel</h1>
          </div>
        </div>
      </div>
    </div>
    <?php 
                    $query = "SELECT *  FROM  buses WHERE b_id =$b_id" ;
                    $select_all_buses = mysqli_query($connection,$query);

                    $count = mysqli_num_rows($select_all_buses);
                    if($count == 0) {
                        echo "<h1>No Products Uploaded</h1>";
                    }
                    else {
                    while($row = mysqli_fetch_assoc($select_all_buses)) {
                        $busid = $row['b_id'];
                        $busno = $row['b_busno'];
                        $busfrom = $row['b_from'];
                        $busto = $row['b_to'];
                        $bustravelname = $row['b_travelname'];
                        $busduration = $row['b_duration'];
                        $busdate = $row['b_date'];
                        $bustype = $row['b_type'];
                        $busboardingstation = $row['b_boardingstation'];
                        $boardingstationtiming = $row['b_boardingstationtiming'];
                        //$busintermediatestation = $row['b_intermediatestation'];
                        //$busintermediatestationtiming = $row['b_intermediatestationtiming'];
                        $busfair = $row['b_fair'];
                        $busnoofseats = $row['b_noofseats'];
                        $busimage = $row['b_image'];
                        $busphoneno = $row['b_phno'];
                        $adminid = $row['a_id'];
                        //$bus_stations = explode(" ",$busintermediatestation);
                        //$bus_times = explode(" ",$busintermediatestationtiming);
                ?>
    <section class="ftco-section ftco-candidates ftco-candidates-2 bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 pr-lg-4">
            <div class="row">
              <div class="col-md-12">
                <div class="team d-md-flex p-4 bg-white">
                  <div
                    class="img"
                    style="background-image: url(busimages/<?php echo $busimage; ?>);"
                  ></div>
                  <div class="text pl-md-4">
          <span class="location mb-0" class="subadge"></span>
                 
					<div class="row">
						<div class="col-md-4">
					  <b><?php echo $bustravelname; ?></b> &NonBreakingSpace; 
						</div>
						<div class="col-md-4">
					  <b><?php echo $busfrom; ?> - <?php echo $busto; ?></b></span>
					</div>
					<div class="col-md-4">
					<span class="position">Depature: <b><?php echo $boardingstationtiming; ?></b></span> - <span class="position">Arrival: <b>7:00</b></span>
				</div>
			</div>

			<div class="row">
				<div class="col-md-4">
                    <p class="mb-2">
                      <?php  echo $busnoofseats; ?>
					</p>
					</div>
					<div class="col-md-4">
						<p class="mb-2">
							<span class="position">Reviews : 4.3</span>
						  </p>
					</div>
					<div class="col-md-4">
						<p class="mb-2">
            <?php  echo $busduration; ?>
						  </p>
					</div>
                  </div>		  
                  </div>
                </div>
              </div>
        </div>
      </div>
    </section>
     
    <section class="ftco-section contact-section bg-light">
      <div class="container">
        <div class="row block-9">
          <div class="col-md-12 order-md-last d-flex">

         
 <h3><?php echo $source; ?></h3>
          </div>

          <div class="col-md-6 d-flex">
            <div id="map" class="bg-white"></div>
          </div>
        </div>
      </div>
    </section>
    <?php }} ?>

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
      <svg class="circular" width="48px" height="48px">
        <circle
          class="path-bg"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke="#eeeeee"
        />
        <circle
          class="path"
          cx="24"
          cy="24"
          r="22"
          fill="none"
          stroke-width="4"
          stroke-miterlimit="10"
          stroke="#F96D00"
        />
      </svg>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
  </html>