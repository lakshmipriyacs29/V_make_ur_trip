-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 08, 2020 at 01:29 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

DROP TABLE IF EXISTS `adminusers`;
CREATE TABLE IF NOT EXISTS `adminusers` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `a_agencyname` varchar(50) NOT NULL,
  `a_type` varchar(15) NOT NULL,
  `a_address` varchar(100) NOT NULL,
  `a_email` varchar(100) NOT NULL,
  `a_pwd` varchar(50) NOT NULL,
  `a_phno` bigint(20) NOT NULL,
  `a_ownername` varchar(20) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`a_id`, `a_agencyname`, `a_type`, `a_address`, `a_email`, `a_pwd`, `a_phno`, `a_ownername`) VALUES
(1, 'KPN TRAVELS', 'bus', 'ksjhhssjjshj', 'kpn@gmail.com', 'asdf1234', 7010455163, 'Prasad'),
(2, 'Harsha Travels ', 'bus', '89, KK Street, Madurai', 'harsha@gmail.com', 'asdf1234', 7010455163, 'Lio'),
(3, 'Prasad', 'bus', '90, takur street', 'bhuvanaprasad.b.tech@gmail.com', 'asdf1234', 7010455163, 'PRASAD'),
(4, 'V7', 'hotel', '106', 'prasadbhu007@gmaill.com', 'asdf1234', 7010455163, 'V7');

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

DROP TABLE IF EXISTS `buses`;
CREATE TABLE IF NOT EXISTS `buses` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_busno` varchar(50) NOT NULL,
  `b_from` varchar(50) NOT NULL,
  `b_to` varchar(50) NOT NULL,
  `b_travelname` varchar(50) NOT NULL,
  `b_duration` varchar(20) NOT NULL,
  `b_date` date NOT NULL,
  `b_type` varchar(20) NOT NULL,
  `b_boardingstation` varchar(500) NOT NULL,
  `b_boardingstationtiming` varchar(500) NOT NULL,
  `b_intermediatestation` varchar(500) NOT NULL,
  `b_intermediatestationtiming` varchar(500) NOT NULL,
  `b_fair` int(11) NOT NULL,
  `b_noofseats` int(11) NOT NULL,
  `b_image` text NOT NULL,
  `b_phno` bigint(20) NOT NULL,
  `a_id` int(11) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`b_id`, `b_busno`, `b_from`, `b_to`, `b_travelname`, `b_duration`, `b_date`, `b_type`, `b_boardingstation`, `b_boardingstationtiming`, `b_intermediatestation`, `b_intermediatestationtiming`, `b_fair`, `b_noofseats`, `b_image`, `b_phno`, `a_id`) VALUES
(8, 'TN90 G7890', 'Chennai', 'Madurai', 'KPN', '10hours', '2020-03-11', 'NON AC', 'Chennai', '8:00P.M.', 'CHENGALPATTU TRICHY', '9:00P.M. 5:00A.M. ', 500, 30, '75c24245.png', 7010455163, 3);

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

DROP TABLE IF EXISTS `hotels`;
CREATE TABLE IF NOT EXISTS `hotels` (
  `h_id` int(11) NOT NULL AUTO_INCREMENT,
  `h_name` varchar(100) NOT NULL,
  `h_address` varchar(100) NOT NULL,
  `h_mobileno` bigint(20) NOT NULL,
  `h_description` varchar(100) NOT NULL,
  `h_ownername` varchar(100) NOT NULL,
  `h_email` varchar(100) NOT NULL,
  `h_roomsavailable` int(11) NOT NULL,
  `h_image` varchar(100) NOT NULL,
  `h_fair` int(11) NOT NULL,
  `a_id` int(11) NOT NULL,
  PRIMARY KEY (`h_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`h_id`, `h_name`, `h_address`, `h_mobileno`, `h_description`, `h_ownername`, `h_email`, `h_roomsavailable`, `h_image`, `h_fair`, `a_id`) VALUES
(1, 'Oyo', '121', 7010455163, 'Sample description', 'Prasad', 'prasadbhu007@gmail.com', 20, '717MrLnX+cL._UY879_.jpg', 200, 4);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `o_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(11) NOT NULL,
  `user_age` int(11) NOT NULL,
  `source` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `cost` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `ticketno` bigint(20) NOT NULL,
  PRIMARY KEY (`o_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `bus_id`, `user_id`, `user_name`, `user_age`, `source`, `destination`, `cost`, `admin_id`, `ticketno`) VALUES
(34, 8, 2, 'kavitha', 23, 'CHENGALPATTU', '', 1000, 3, 1442397725),
(33, 8, 2, 'Harini', 23, 'CHENGALPATTU', '', 1000, 3, 1442397725),
(32, 8, 1, 'PRASAD', 23, 'CHENGALPATTU', '', 500, 3, 411598642);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phonenumber` bigint(20) NOT NULL,
  `city` varchar(100) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `emailid`, `password`, `phonenumber`, `city`) VALUES
(1, 'Prasad', 'bhuvanaprasad.b.tech@gmail.com', 'asdf1234', 7010455163, 'Madurai'),
(2, 'Harini', 'harini@gmail.com', '1234', 789545454544, 'Madurai');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
