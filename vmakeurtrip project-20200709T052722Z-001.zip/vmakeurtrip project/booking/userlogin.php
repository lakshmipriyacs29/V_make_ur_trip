<?php include "config.php"; ob_start(); ?>
<?php session_start(); ?>
<?php 

if (isset($_POST['userlogin'])) {
	$emailid = $_POST['u_emailid'];
	$password = $_POST['u_password'];

	$query = "SELECT * FROM users WHERE emailid = '$emailid'";
	$select_user = mysqli_query($connection,$query);

	if (!$select_user) {
		die("Query Failed" . mysqli_error($connection));
    }

	while ($row = mysqli_fetch_assoc($select_user)) {
        $db_u_id=$row['u_id'];
		$db_u_username = $row['username'];
        $db_u_email = $row['emailid'];
        $db_u_pwd = $row['password'];
        $db_u_phno = $row['phonenumber'];
        $db_u_city = $row['city'];

		if($emailid === $db_u_email && $password === $db_u_pwd) {
            $_SESSION['u_id']=$db_u_id;
		    $_SESSION['username']=$db_u_username;
		    $_SESSION['emailid']=$db_u_email;
		    $_SESSION['city']=$db_u_city;
			header("Location: homepage.php");
			exit;			
		}
		else {
			echo("Password is wrong");
			exit;
		}
	}
}

?>