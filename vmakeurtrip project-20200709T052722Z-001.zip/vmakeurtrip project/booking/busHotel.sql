-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2020 at 06:41 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE IF NOT EXISTS `adminusers` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `a_agencyname` varchar(50) NOT NULL,
  `a_type` varchar(15) NOT NULL,
  `a_address` varchar(100) NOT NULL,
  `a_email` varchar(100) NOT NULL,
  `a_pwd` varchar(50) NOT NULL,
  `a_phno` bigint(20) NOT NULL,
  `a_ownername` varchar(20) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`a_id`, `a_agencyname`, `a_type`, `a_address`, `a_email`, `a_pwd`, `a_phno`, `a_ownername`) VALUES
(1, 'KPN TRAVELS', 'bus', '89, KK Street, Madurai', 'kpn@gmail.com', '123', 7010455163, 'K.P.Karupu'),
(2, 'KaKapo', 'hotel', '110, Villapuram, Madurai-12', 'k@gmail.com', '12', 8124366206, 'Karthick'),
(7, 'VRL Travels', 'bus', '22,srt street,Madurai,Tamil Nadu', 'vrltravels@gmail.com', '123', 4567890978, 'vrl'),
(8, 'SRM Travels', 'bus', '34,vishal road,Bangaluru', 'srmtravels@gmail.com', '123', 3849734738, 'Santhosh'),
(9, 'SVR Travels', 'bus', '12,TPK Main street,Madurai', 'svrtravels@gmail.com', '123', 454759579, 'Harini'),
(10, 'SRS Travels', 'bus', '12, Maaret Street, South Therkuvasal Bus Stop, South Gate, Madurai, Tamil Nadu', 'srstravels@gmail.com', '123', 8577307934, 'srs');

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE IF NOT EXISTS `buses` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_busno` varchar(50) NOT NULL,
  `b_from` varchar(50) NOT NULL,
  `b_to` varchar(50) NOT NULL,
  `b_travelname` varchar(50) NOT NULL,
  `b_duration` varchar(20) NOT NULL,
  `b_date` date NOT NULL,
  `b_type` varchar(20) NOT NULL,
  `b_boardingstation` varchar(500) NOT NULL,
  `b_boardingstationtiming` varchar(500) NOT NULL,
  `b_bordingstationarrival` varchar(500) NOT NULL,
  `b_fair` int(11) NOT NULL,
  `b_noofseats` int(11) NOT NULL,
  `b_image` text NOT NULL,
  `b_phno` bigint(20) NOT NULL,
  `a_id` int(11) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`b_id`, `b_busno`, `b_from`, `b_to`, `b_travelname`, `b_duration`, `b_date`, `b_type`, `b_boardingstation`, `b_boardingstationtiming`, `b_bordingstationarrival`, `b_fair`, `b_noofseats`, `b_image`, `b_phno`, `a_id`) VALUES
(2, 'TN90 G7890', 'Chennai', 'Madurai', 'KPN', '10hours', '2020-03-26', 'NON AC', 'Chennai', '8:00 P.M', '7.00 A.M', 500, 30, '75c24245.png', 7010455163, 1),
(1, 'TN59K1208', 'chennai', 'madurai', 'KAKAPO Travels', '8 hours', '2020-03-26', 'AC', 'chennai', '9.00 Pm', '5.00 Am', 600, 45, 'download.jfif', 8220267788, 1),
(11, 'TN 64 k 4123', 'BANGALURU', 'CHENNAI', 'KPN Travels', '5hr 20mins', '2020-03-30', 'non Ac', 'Electronic City', '9:55 AM', '3:15 PM', 600, 40, 'kpn.jpg', 873473984, 1),
(12, 'TN 64 k 4512', 'CHENNAI', 'BANGALURU', 'KPN Travels', '6h 32mins', '2020-03-30', 'AC ', 'Ashok Pillar', '9:35 PM', '4:07 AM', 300, 30, 'kpn.jpg', 96986868, 1),
(13, 'TN 64 k 7898', 'BANGALURU', 'CHENNAI', 'VRL TRAVELS', '6h 13mins', '2020-03-30', 'AC ', 'Amba Bajaj, Madiwala', '10:00 PM', '3:25 AM', 400, 20, 'vrl-travels.jpg', 675858586, 7),
(14, 'TN 64 k 5321', 'MADURAI', 'BANGALURU', 'VRL TRAVELS', '6h 27mins', '2020-03-31', 'AC ', 'Fathima college', '11:05 PM', '5:32 AM', 600, 30, 'vrl-travels.jpg', 9087675654, 7),
(15, 'TN 64 k 1122', 'MADURAI', 'COIMBATORE', 'VRL TRAVELS', '5hr 27mins', '2020-03-30', 'Non AC', 'Mattuthavani', '10:00PM', '3:25 AM', 450, 45, 'vrl-travels.jpg', 9087656437, 7),
(16, 'TN 64 k 0965', 'TRICHY', 'CHENNAI', 'VRL TRAVELS', '6hr 5 mins', '2020-04-01', 'Non AC', 'Tvs Tolgate', '10:45 AM', '5:02 PM', 289, 20, 'vrl-travels.jpg', 876868575, 7),
(17, 'TN 64 k 7656', 'ERODE', 'COIMBATORE', 'VRL TRAVELS', '1 h 45 min', '2020-03-02', 'AC ', 'Erode Junction', '3:15 AM', '5:00 AM', 439, 35, 'vrl-travels.jpg', 7979696697, 7),
(18, 'TN 64 H 2345', 'BANGALURU', 'CHENNAI', 'SRM TRAVELS', '5hr 20mins', '2020-03-30', 'Ac', 'Electronic City', '2:00PM', '8:20 PM', 456, 30, 'srmtravels.jpg', 898765654, 8),
(19, 'TN 64 M 1111', 'MADURAI', 'BANGALURU', 'SRM TRAVELS', '6hr 42mins', '2020-03-31', 'AC ', 'Fathima college', '11:00 PM', '5:42 AM', 250, 25, 'srmtravels.jpg', 454563466, 8),
(20, 'TN 32 G 4674', 'MADURAI', 'COIMBATORE', 'SVR TRAVELS', '4hr 37mins', '2020-03-30', 'Non AC', 'Fathima college', '11:45 PM', '5:32 AM', 350, 40, 'svr.jpg', 7967686876, 9),
(21, 'TN 45 M 6787', 'TRICHY', 'CHENNAI', 'SVR TRAVELS', '5hr 20mins', '2020-03-01', 'AC ', 'Tvs Tolgate', '11:14 PM', '4:42 PM', 400, 20, 'svr.jpg', 6876686865, 9),
(22, 'TN 32 N 4557', 'ERODE', 'COIMBATORE', 'SRS TRAVELS', '2 h 18 min', '2020-04-02', 'AC ', 'Erode Junction', '8:25 PM', '10:52 PM', 239, 20, 'srstravels.jpg', 676855855, 10),
(23, 'TN 64 N 4123', 'CHENNAI', 'BANGALURU', 'SRS TRAVELS', '5 h 37 min', '2020-03-30', 'Non AC', 'Koyambedu', '11:00 PM', '5:07 AM', 300, 30, 'srstravels.jpg', 7676866998, 10);

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE IF NOT EXISTS `hotels` (
  `h_id` int(11) NOT NULL AUTO_INCREMENT,
  `h_name` varchar(100) NOT NULL,
  `h_address` varchar(100) NOT NULL,
  `h_mobileno` bigint(20) NOT NULL,
  `h_description` varchar(100) NOT NULL,
  `h_city` varchar(100) NOT NULL,
  `h_ownername` varchar(100) NOT NULL,
  `h_email` varchar(100) NOT NULL,
  `h_roomsavailable` int(11) NOT NULL,
  `h_image` varchar(100) NOT NULL,
  `h_fair` int(11) NOT NULL,
  `a_id` int(11) NOT NULL,
  PRIMARY KEY (`h_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`h_id`, `h_name`, `h_address`, `h_mobileno`, `h_description`, `h_city`, `h_ownername`, `h_email`, `h_roomsavailable`, `h_image`, `h_fair`, `a_id`) VALUES
(3, 'Hotel Sabaris', '21A K.P.K ROAD MADURAI', 7894561331, 'Enjoy', 'madurai', 'Prasad', 'prasadbhu007@gmail.com', 12, 'analytics.png', 300, 4),
(4, 'Sharmi Illlam', 'No 6, Krishnapuram Colony, Madurai', 822061188, 'Nambi Vanga Appu oda Ponga', 'Madurai', 'Sharmila', 'sharmi@gmail.com', 15, 'analytics.png', 250, 4),
(5, 'Panda Hotel', '12, Gundama Street, Kulli Road, Madurai-12', 9150635612, 'Eruma Madu', 'Madurai', 'Kavitha Kavi', 'kavikulli@gmail.com', 35, 'logo3.png', 100, 2);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(100) NOT NULL,
  PRIMARY KEY (`no`),
  UNIQUE KEY `no` (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`no`, `city`) VALUES
(1, 'CHENNAI'),
(2, 'MADURAI'),
(3, 'COIMBATORE'),
(4, 'BANGALURU'),
(5, 'SALEM'),
(6, 'TRICHY'),
(7, 'ERODE');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `o_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_age` varchar(100) NOT NULL,
  `source` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `cost` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `ticketno` bigint(20) NOT NULL,
  PRIMARY KEY (`o_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `bus_id`, `user_id`, `user_name`, `user_age`, `source`, `destination`, `cost`, `admin_id`, `ticketno`) VALUES
(51, 8, 2, 'a:2:{i:0;s:6:"Prasad";i:1;s:3:"Ram";}', 'a:2:{i:0;s:2:"20";i:1;s:2:"20";}', 'CHENGALPATTU', 'TRICHY', 1000, 3, 1735188268);

-- --------------------------------------------------------

--
-- Table structure for table `orderss`
--

CREATE TABLE IF NOT EXISTS `orderss` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `b_travelname` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `edate` date NOT NULL,
  `efrom` varchar(100) NOT NULL,
  `eto` varchar(100) NOT NULL,
  `no_of_ticket` int(11) NOT NULL,
  `ticketno` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  PRIMARY KEY (`no`),
  UNIQUE KEY `no` (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `orderss`
--

INSERT INTO `orderss` (`no`, `admin_id`, `bus_id`, `b_travelname`, `user_id`, `user_name`, `edate`, `efrom`, `eto`, `no_of_ticket`, `ticketno`, `cost`) VALUES
(6, 1, 3, 'KPN Travels', 2, 'Harini', '2020-03-31', 'Madurai ', 'Chennai', 2, 23354, 1700),
(7, 1, 2, 'KPN Travels', 2, 'Harini', '2020-03-31', 'Chennai ', 'Madurai', 2, 29373, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `order_hotel`
--

CREATE TABLE IF NOT EXISTS `order_hotel` (
  `o_id` int(11) NOT NULL AUTO_INCREMENT,
  `h_id` int(11) NOT NULL,
  `h_name` varchar(100) NOT NULL,
  `h_address` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `checkin` date NOT NULL,
  `checkout` date NOT NULL,
  `cost` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `ticketno` int(20) NOT NULL,
  PRIMARY KEY (`o_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `order_hotel`
--

INSERT INTO `order_hotel` (`o_id`, `h_id`, `h_name`, `h_address`, `user_id`, `user_name`, `address`, `phone`, `checkin`, `checkout`, `cost`, `admin_id`, `ticketno`) VALUES
(1, 5, 'Panda Hotel', '12, Gundama Street, Kulli Road, Madurai-12', 2, 'Harini', 'Anupanadi', '9150635612', '2020-03-31', '2020-04-03', 300, 2, 19355);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phonenumber` bigint(20) NOT NULL,
  `city` varchar(100) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `emailid`, `password`, `phonenumber`, `city`) VALUES
(2, 'Harini', 'harini@gmail.com', '1234', 9545454544, 'Madurai'),
(3, 'Kavitha', 'kakapo@gmail.com', '1234', 9150635612, 'Madurai');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
