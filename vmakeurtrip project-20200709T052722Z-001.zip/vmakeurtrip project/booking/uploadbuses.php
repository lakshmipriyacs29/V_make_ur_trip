<?php
    include "config.php";
    session_start();
    if (isset($_POST['uploadbus'])) {
        $b_busno = $_POST['b_busno'];
        $b_from = $_POST['b_from'];
        $b_to = $_POST['b_to'];
        $b_travelname = $_POST['b_travelname'];
        $b_duration = $_POST['b_duration'];
        $b_date = $_POST['b_dateofjourney'];
        $b_type = $_POST['b_type'];
        $b_boardingstation = $_POST['b_boardingstation'];
        $b_boardingstationtiming = $_POST['b_boardingstationtiming'];
        $b_boardingstationarrival=$_POST['b_boardingstationarrival'];
        $b_fair = $_POST['b_fair'];
        $b_noofseats = $_POST['b_noofseats'];
        $b_image = $_FILES['b_image']['name'];
        $tmp_image = $_FILES['b_image']['tmp_name'];
        move_uploaded_file($tmp_image, "busimages/$b_image");
        $b_phno = $_POST['b_phno'];
        $a_id = $_SESSION['a_id'];
    $query = "INSERT INTO buses(b_busno, b_from, b_to, b_travelname, b_duration,b_date,b_type, b_boardingstation,b_boardingstationtiming,b_fair,b_noofseats,b_image,b_phno,a_id,b_bordingstationarrival) VALUES('$b_busno', '$b_from', '$b_to', '$b_travelname', '$b_duration','$b_date', '$b_type', '$b_boardingstation','$b_boardingstationtiming','$b_fair','$b_noofseats','$b_image','$b_phno','$a_id','$b_boardingstationarrival') ";
    
    $addbus = mysqli_query($connection, $query);
    
    if(!$addbus) {
        die("Query Failed" . mysqli_error($connection));
    }
    
    header("Location: uploadbus.php");
    }
    
    ?>