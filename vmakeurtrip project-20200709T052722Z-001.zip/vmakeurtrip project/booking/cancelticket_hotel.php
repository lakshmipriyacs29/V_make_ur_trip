<?php
    include "config.php";
    $selected_ticket = $_GET['o_id'];
    $query = "DELETE FROM order_hotel wHERE o_id = '$selected_ticket'";
    $deleteticket = mysqli_query($connection, $query);
    
    if(!$deleteticket) {
        die("Query Failed" . mysqli_error($connection));
    } 
    header("Location: mytickets.php");   
?>