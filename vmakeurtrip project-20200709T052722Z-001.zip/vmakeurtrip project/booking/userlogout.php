<?php session_start(); ?>
<?php 
 $_SESSION['u_id']=null;
 $_SESSION['username']=null;
 $_SESSION['emailid']=null;
 $_SESSION['city']=null;

header("Location: userlogin.html");

?>